export const GlobalStyles = {
  colors: {
    primary50: '#FFFADD',
    primary100: '#c6affc',
    primary200: '#FFCC70',
    primary400: '#22668D',
    primary500: '#22668D',
    primary700: '#8ECDDD',
    primary800: '#8ECDDD',
    accent500: '#FFFADD',
    error50: '#fcc4e4',
    error500: '#22668D',
    gray500: '#39324a',
    gray700: '#221c30',
  },
};