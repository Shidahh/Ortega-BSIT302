import React from 'react';
import { View, TextInput, StyleSheet, Text } from 'react-native';

function Input({ label, TextInputConfig }) {
  return (
    <View style={styles.inputContainer}>
      <Text style={styles.label}>{label}</Text>
      <TextInput {...TextInputConfig} style={styles.input} />
    </View>
  );
}

function ExpenseForm() {
  function amountChangeHandler() {}

  return (
    <View style={styles.container}>
      <Input label="Amount" TextInputConfig={{ keyboardType: 'decimal-pad', onChangeText: amountChangeHandler }} />
      <Input label="Date" TextInputConfig={{ placeholder: 'YYYY/MM/DD', maxLength: 10, onChangeText: () => {} }} />
      <Input label="Description" TextInputConfig={{ multiline: true }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 5,
  },
  inputContainer: {
    marginBottom: 10,
  },
  label: {
    backgroundColor: 'yellow',
    padding: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: 'blue',
    borderRadius: 5,
    padding: 5,
    width: '100%',
  },
});

export default ExpenseForm;

